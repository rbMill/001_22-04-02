opencv_version = "4.4.0.40"
contrib = False
headless = True
ci_build = True